﻿using System;
using System.IO;
using System.Text;
using AsarCLR;

namespace Unpatcher {
    class Program {
        static void Main(string[] args) {
            string patch = "patch.asm", rom, original = "smwOrig.smc", unpatch_file = "unpatch.asm";

            bool output = false, keepfiles = false, runOnOriginal = false;

            if (args.Length > 1) {
                for (int i = 0; i < args.Length; i++) {
                    if (args[i] == "-patch" && i < args.Length - 2) {
                        patch = args[++i];
                    } else if (args[i] == "-orig" && i < args.Length - 2) {
                        original = args[++i];
                    } else if (args[i] == "-unpatch" && i < args.Length - 2) {
                        unpatch_file = args[++i];
                    } else if (args[i] == "-o") {
                        output = true;
                    } else if (args[i] == "-k") {
                        keepfiles = true;
                    } else if (args[i] == "-f") {
                        runOnOriginal = true;
                    } else if(i != args.Length - 1) {
                        Console.WriteLine($"Error. Unknown or invalid option \"{args[i]}\"");
                    }
                }
                rom = args[args.Length - 1];
            } else if (args.Length == 1) {
                rom = args[0];
            } else {
                Console.Write("Enter rom name or drag and drop here: ");
                rom = Console.ReadLine();
            }
            
            try {
                UnpatchROM(patch, rom, original, runOnOriginal, output, keepfiles, unpatch_file);
            } catch (Exception ex) {
                Console.WriteLine("Error: {0}", ex.Message);
            }

            Console.Write("Press any key to exit. . . ");
            Console.ReadKey();
        }

        public static void patch_rom(ROM rom, string patch) {
            if(!rom.patch(patch)) {
                foreach (Asarerror err in rom.lastErrors)
                    Console.WriteLine(err.Fullerrdata);

                foreach (Asarerror warn in rom.lastWarnings)
                    Console.WriteLine(warn.Fullerrdata);

                Console.WriteLine($"Errors were detected while inserting the patch on ROM \"{rom.filename}\". Do you still want to try and remove it? (y/n)");
                while (true) {
                    ConsoleKeyInfo cki = Console.ReadKey(true);
                    if (cki.Key == ConsoleKey.Y)     break;
                    else if(cki.Key == ConsoleKey.N) throw new Exception("An error occurred while trying to apply the patch. No changes have been made to the ROM.");
                }
            }
        }

        public static void UnpatchROM(string patch, string rom, string original, bool runOnOriginal, bool output, bool keepfiles, string unpatch_file){
            if (!File.Exists(patch)) { throw new Exception($"Patch file \"{patch}\" does not exist"); }
            if (!File.Exists(rom)) { throw new Exception($"ROM file \"{rom}\" does not exist"); }
            if (!File.Exists(original)) { throw new Exception($"Base ROM \"{original}\" does not exist"); }

            if (!Asar.init()) { throw new Exception("Could not initialize Asar");}

            ROM r_rom = new ROM(rom);
            ROM r_orig = new ROM(original);

            byte[] romDataCopy = r_rom.GetROMDataCopy();

            patch_rom(r_rom, patch);

            StringBuilder sb_patch = new StringBuilder();

            foreach (Asarwrittenblock written in r_rom.lastWrittenBlocks) {
                if ((written.Snesoffset & 0x7FFFFF) > 0x0FFFFF) {
                    sb_patch.AppendFormat("autoclean ${0:X6}\n", written.Snesoffset);
                } else if(!runOnOriginal) {
                    sb_patch.AppendFormat("org ${0:X6}\ndb ", written.Snesoffset & 0x7FFFFF);
                    byte[] data = r_orig.ReadData(written.Pcoffset, written.Numbytes);
                    foreach (byte b in data) sb_patch.AppendFormat("${0:X2},", b);
                    sb_patch[sb_patch.Length - 1] = '\n';
                }
            }

            if (runOnOriginal) {
                byte[] originalData = r_orig.GetROMDataCopy();
                patch_rom(r_orig, patch);

                foreach (Asarwrittenblock written in r_orig.lastWrittenBlocks) {
                    if ((written.Snesoffset & 0x7FFFFF) < 0x100000) {
                        sb_patch.AppendFormat("org ${0:X6}\ndb ", written.Snesoffset & 0x7FFFFF);
                        byte[] data = new byte[written.Numbytes];
                        Array.Copy(originalData, written.Pcoffset, data, 0, written.Numbytes);
                        foreach (byte b in data) sb_patch.AppendFormat("${0:X2},", b);
                        sb_patch[sb_patch.Length - 1] = '\n';
                    }
                }
            }

            File.WriteAllText(unpatch_file, sb_patch.ToString());

            if (output) return; // If program is set to generate output it's job is done at this point.

            r_rom.patch(unpatch_file);

            r_rom.Save();

            if (!keepfiles) {
                for (int i = 0; i < 999; i++) {
                    try {
                        File.Delete(unpatch_file);
                    } catch {
                        if (i == 999) {
                            Console.WriteLine($"Error: Could not delete temporary file {unpatch_file}");
                        }
                    }
                }
            }
        }
    }
}
