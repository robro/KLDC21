﻿using System;
using System.IO;
using AsarCLR;

namespace Unpatcher {
    class ROM {
        const int maxRomSize = 8389120;     // 8mb + header
        const int minRomSize = 524288;      // 512kb

        int romSize;

        public string filename;

        byte[] romData;
        byte[] header;
        
        bool containsHeader;

        public Asarerror[] lastErrors;
        public Asarerror[] lastWarnings;

        public Asarwrittenblock[] lastWrittenBlocks;

        public ROM(string filename) {
            this.romData = File.ReadAllBytes(filename);
            this.filename = filename;

            int romLength = romData.Length;

            if (romLength > maxRomSize) throw new Exception("ROM too large!");
            if (romLength < minRomSize) throw new Exception("ROM too small for Super Mario World!");

            this.containsHeader = (romLength % 0x8000) == 512;

            if ((romLength % 0x8000) != 0 && !this.containsHeader)
                throw new Exception("Invalid ROM block align! ROM corrupted?");
            
            string smw = "SUPER MARIOWORLD     ";

            int position = 0x7FC0 + (this.containsHeader ? 512 : 0);

            foreach (char character in smw) {
                if (romData[position++] != character)
                    throw new Exception("This isn't a Super Mario World ROM!");
            }

            romSize = romLength - (this.containsHeader ? 512 : 0);
            header = new byte[512];

            if (this.containsHeader) {
                byte[] dupe = new byte[romSize];
                Array.Copy(romData, 0, header, 0, 512);
                Array.Copy(romData, 512, dupe, 0, romSize);
                romData = null;
                romData = dupe;
                dupe = null;
            }
        }

        public void Save() {
            byte[] data = new byte[this.romData.Length + ((this.containsHeader) ? 512 : 0)];

            if (this.containsHeader) {
                Array.Copy(this.header, data, 512);
            }

            Array.Copy(this.romData, 0, data, (this.containsHeader) ? 512 : 0, this.romData.Length);

            File.WriteAllBytes(this.filename, data);
        }

        public bool patch(string filename) {
            bool res = Asar.patch(filename, ref this.romData);
            this.lastErrors = Asar.geterrors();
            this.lastWarnings = Asar.getwarnings();
            this.lastWrittenBlocks = Asar.getwrittenblocks();
            return res;
        }

        public byte[] ReadData(int location, int size) {
            if (location + size > this.romData.Length) { throw new Exception("Location out of bounds"); }

            byte[] data = new byte[size];
            Array.Copy(this.romData, location, data, 0, size);
            return data;
        }

        public byte[] GetROMDataCopy() {
            byte[] copy = new byte[this.romData.Length];
            Array.Copy(this.romData, copy, this.romData.Length);
            return copy;
        }
    }
}
